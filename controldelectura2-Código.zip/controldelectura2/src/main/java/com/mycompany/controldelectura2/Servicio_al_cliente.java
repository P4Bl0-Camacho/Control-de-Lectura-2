package com.mycompany.controldelectura2;

public class Servicio_al_cliente {

    private Object ID_de_la_empresa;

    public void Atencion_en_linea() {
    }

    public void Atencion_telefonica() {
    }
}
