/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.controldelectura2;

/**
 *
 * @author MSI
 */
public class Controldelectura2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
