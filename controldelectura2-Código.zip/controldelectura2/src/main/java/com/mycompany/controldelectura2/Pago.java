package com.mycompany.controldelectura2;

public class Pago {

    private Object Prepago;

    public void Transferencia_bancaria() {
    }

    public void Pago_en_linea() {
    }
}
