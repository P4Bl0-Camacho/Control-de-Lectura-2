package com.mycompany.controldelectura2;

public class Hotel {

    private Object Nombre;

    private Object Telefono;

    private Object Numero_de_cuenta;

    public void Hospedaje_de_clientes() {
    }
}
