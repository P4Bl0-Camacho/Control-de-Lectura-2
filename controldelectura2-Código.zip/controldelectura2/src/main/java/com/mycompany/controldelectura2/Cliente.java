package com.mycompany.controldelectura2;

public class Cliente {

    private Object Nombre;

    private Object Datos_Bancarios;

    private Object Telefono;

    public void Reservar_en_linea() {
    }

    public void Reservar_en_presencial() {
    }
}
