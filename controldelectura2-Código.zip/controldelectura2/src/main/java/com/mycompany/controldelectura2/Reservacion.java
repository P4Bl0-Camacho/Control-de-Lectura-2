package com.mycompany.controldelectura2;

public class Reservacion {

    private Object Tipo_de_habitacion;

    private Object Desayuno;

    private Object Spa;

    private Object Disponibilidad;

    public void Hospedaje() {
    }

    public void Servicio_de_alimentacion() {
    }

    public void Servicio_actividades_de_Spa() {
    }
}
